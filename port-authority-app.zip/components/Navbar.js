import Link from 'next/link'

export default function Navbar(){
  return (
    <nav className="bg-white p-4 shadow">
      <div className="max-w-6xl mx-auto flex justify-between items-center">
        <Link href="/"><a className="font-bold">Port Authority</a></Link>
        <div className="space-x-2">
          <Link href="/admin"><a className="px-2 py-1 rounded bg-blue-50">Admin</a></Link>
          <Link href="/client/track"><a className="px-2 py-1 rounded bg-green-50">Track</a></Link>
        </div>
      </div>
    </nav>
  )
}
