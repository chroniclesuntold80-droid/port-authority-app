import Link from 'next/link'

export default function Home(){
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="max-w-xl w-full p-6 bg-white rounded shadow">
        <h1 className="text-2xl font-bold mb-4">Port Authority — Clearance System (MVP)</h1>
        <p className="mb-4">Admin creates items & manages clearance. Clients track by tracking number.</p>
        <div className="space-x-2">
          <Link href='/admin'><a className="bg-blue-600 text-white px-4 py-2 rounded">Admin Dashboard</a></Link>
          <Link href='/client/track'><a className="bg-green-600 text-white px-4 py-2 rounded">Track Item</a></Link>
        </div>
      </div>
    </div>
  )
}
