import pdfMake from "pdfmake/build/pdfmake"
import pdfFonts from "pdfmake/build/vfs_fonts"

pdfMake.vfs = pdfFonts.pdfMake.vfs

export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const { itemName, trackingId, clientName } = req.body

  const docDefinition = {
    content: [
      { text: 'Port Authority — Clearance Invoice', style: 'header', margin: [0,0,0,8] },
      { text: `Client: ${clientName}` },
      { text: `Item: ${itemName}` },
      { text: `Tracking ID: ${trackingId}` },
      { text: `Date: ${new Date().toLocaleString()}` },
      { text: '\nThis document is a system-generated record of clearance processing.' }
    ],
    styles: {
      header: { fontSize: 16, bold: true }
    }
  }

  const pdfDoc = pdfMake.createPdf(docDefinition)
  pdfDoc.getBase64((data) => {
    res.setHeader("Content-Type", "application/pdf")
    res.send(Buffer.from(data, "base64"))
  })
}
