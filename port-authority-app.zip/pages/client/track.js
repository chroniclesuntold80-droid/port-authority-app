import { useState } from 'react'
import supabase from '@/lib/supabaseClient'

const translations = {
  en: {
    Pending: "Pending",
    "In Review": "In Review",
    Cleared: "Cleared",
    "In Transit": "In Transit",
    Delivered: "Delivered"
  },
  tl: {
    Pending: "Nakabinbin",
    "In Review": "Sinusuri",
    Cleared: "Naaprubahan",
    "In Transit": "Nasa biyahe",
    Delivered: "Naihatid"
  }
}

export default function TrackItem() {
  const [trackingId, setTrackingId] = useState('')
  const [status, setStatus] = useState(null)
  const [language, setLanguage] = useState('en')

  const handleTrack = async () => {
    const { data, error } = await supabase
      .from('items')
      .select('status, item_name, department, client_name')
      .eq('tracking_id', trackingId)
      .single()
    if (error) {
      alert(error.message || "Not found")
      setStatus(null)
      return
    }
    setStatus(data)
  }

  return (
    <div className="p-6 max-w-lg mx-auto">
      <h1 className="text-xl font-bold mb-4">
        {language === 'en' ? "Track Your Item" : "Subaybayan ang Iyong Kargamento"}
      </h1>
      <select 
        value={language}
        onChange={(e) => setLanguage(e.target.value)}
        className="border p-2 mb-3"
      >
        <option value="en">English</option>
        <option value="tl">Tagalog</option>
      </select>
      <input 
        type="text"
        placeholder={language === 'en' ? "Enter Tracking Number" : "Ilagay ang Numero ng Tracking"}
        onChange={(e) => setTrackingId(e.target.value)}
        className="border p-2 my-2 w-full rounded"
      />
      <button 
        onClick={handleTrack}
        className="bg-green-600 text-white px-4 py-2 rounded w-full">
        {language === 'en' ? "Track" : "Subaybayan"}
      </button>

      {status && (
        <div className="mt-6 border p-4 rounded bg-white">
          <p><strong>{language === 'en' ? "Client" : "Kliyente"}:</strong> {status.client_name}</p>
          <p><strong>{language === 'en' ? "Item" : "Bagay"}:</strong> {status.item_name}</p>
          <p><strong>{language === 'en' ? "Department" : "Departamento"}:</strong> {status.department}</p>
          <p className="font-semibold mt-2">
            {language === 'en' ? "Current Status" : "Kasalukuyang Katayuan"}: {translations[language][status.status]}
          </p>
        </div>
      )}

      {/* JivoChat widget (replace JIVO_WIDGET_CODE in env) */}
      <script dangerouslySetInnerHTML={{
        __html: `window.jivo_init = window.jivo_init || function(){}; (function(){var w=window;var d=document;var s=d.createElement('script');s.async=true;s.src='//code.jivosite.com/widget/' + (process.env.JIVO_WIDGET_CODE || 'YOUR_WIDGET_CODE');d.head.appendChild(s);})();`
      }} />
    </div>
  )
}
