import { useEffect, useState } from 'react'
import supabase from '@/lib/supabaseClient'

export default function AdminDashboard() {
  const [items, setItems] = useState([])
  const [newItem, setNewItem] = useState({ item_name: '', client_name: '', department: '' })

  useEffect(() => { fetchItems() }, [])

  const fetchItems = async () => {
    const { data, error } = await supabase.from('items').select('*').order('created_at', {ascending: false})
    if (!error) setItems(data || [])
  }

  const addItem = async () => {
    const trackingId = `PA-${Date.now()}`
    await supabase.from('items').insert([{ ...newItem, tracking_id: trackingId, status: 'Pending' }])
    setNewItem({ item_name: '', client_name: '', department: '' })
    fetchItems()
  }

  const updateStatus = async (id, status) => {
    await supabase.from('items').update({ status }).eq('id', id)
    fetchItems()
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>

      <div className="mt-6 border p-4 rounded bg-white">
        <h2 className="text-lg font-semibold mb-2">Add New Item</h2>
        <div className="flex flex-wrap gap-2">
          <input 
            placeholder="Client Name"
            value={newItem.client_name}
            onChange={(e) => setNewItem({...newItem, client_name: e.target.value})}
            className="border p-2 rounded flex-1 min-w-[200px]"
          />
          <input 
            placeholder="Item Name"
            value={newItem.item_name}
            onChange={(e) => setNewItem({...newItem, item_name: e.target.value})}
            className="border p-2 rounded flex-1 min-w-[200px]"
          />
          <select 
            value={newItem.department}
            onChange={(e) => setNewItem({...newItem, department: e.target.value})}
            className="border p-2 rounded"
          >
            <option value="">Select Department</option>
            <option value="Customs">Customs</option>
            <option value="Agriculture">Agriculture</option>
            <option value="Quarantine">Quarantine</option>
            <option value="Coast Guard">Coast Guard</option>
          </select>
          <button onClick={addItem} className="bg-blue-600 text-white px-4 py-2 rounded">Add</button>
        </div>
      </div>

      <table className="w-full border mt-6 bg-white">
        <thead>
          <tr>
            <th className="border p-2">Tracking #</th>
            <th className="border p-2">Client</th>
            <th className="border p-2">Item</th>
            <th className="border p-2">Department</th>
            <th className="border p-2">Status</th>
            <th className="border p-2">Action</th>
          </tr>
        </thead>
        <tbody>
          {items.map(item => (
            <tr key={item.id}>
              <td className="border p-2">{item.tracking_id}</td>
              <td className="border p-2">{item.client_name}</td>
              <td className="border p-2">{item.item_name}</td>
              <td className="border p-2">{item.department}</td>
              <td className="border p-2">{item.status}</td>
              <td className="border p-2 space-x-2">
                <button onClick={() => updateStatus(item.id, 'In Review')} className="bg-yellow-500 text-white px-2 py-1 rounded">Review</button>
                <button onClick={() => updateStatus(item.id, 'Cleared')} className="bg-green-600 text-white px-2 py-1 rounded">Clear</button>
                <button onClick={() => updateStatus(item.id, 'In Transit')} className="bg-blue-500 text-white px-2 py-1 rounded">Transit</button>
                <button onClick={() => updateStatus(item.id, 'Delivered')} className="bg-purple-600 text-white px-2 py-1 rounded">Delivered</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
